package br.mackenzie.chutesal.domain.inscrito.service;

import br.mackenzie.chutesal.domain.inscrito.Inscrito;
import br.mackenzie.chutesal.util.crud.CrudService;

public interface InscritoService extends CrudService<Inscrito> {


}
