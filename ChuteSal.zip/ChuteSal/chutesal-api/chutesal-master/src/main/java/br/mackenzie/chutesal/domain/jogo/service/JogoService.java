package br.mackenzie.chutesal.domain.jogo.service;

import br.mackenzie.chutesal.domain.jogo.Jogo;
import br.mackenzie.chutesal.util.crud.CrudService;

public interface JogoService extends CrudService<Jogo> {
}
