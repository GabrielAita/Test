package br.mackenzie.chutesal.domain.quadra.service;

import br.mackenzie.chutesal.domain.quadra.Quadra;
import br.mackenzie.chutesal.util.crud.CrudService;

public interface QuadraService extends CrudService<Quadra> {
}
