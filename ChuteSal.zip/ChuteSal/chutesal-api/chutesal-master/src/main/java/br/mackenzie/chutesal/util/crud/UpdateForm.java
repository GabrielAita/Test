package br.mackenzie.chutesal.util.crud;

public interface UpdateForm<T> {

    T update(T entity);
}
