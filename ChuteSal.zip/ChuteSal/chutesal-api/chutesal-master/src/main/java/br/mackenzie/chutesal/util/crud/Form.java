package br.mackenzie.chutesal.util.crud;

public interface Form<T> {

    T convert();
}
