package br.mackenzie.chutesal.util.status;

public enum Status {
    PLANEJADO,
    ANDAMENTO,
    CANCELADO,
    EXECUTADO
}
