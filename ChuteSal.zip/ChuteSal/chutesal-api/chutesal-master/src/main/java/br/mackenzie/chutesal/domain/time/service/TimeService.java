package br.mackenzie.chutesal.domain.time.service;

import br.mackenzie.chutesal.domain.time.Time;
import br.mackenzie.chutesal.util.crud.CrudService;

public interface TimeService extends CrudService<Time> {
}
