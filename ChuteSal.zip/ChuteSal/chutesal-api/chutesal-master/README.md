<h1> Gerenciador de Campeonatos da Escola "ChuteSal" </h1>
<p> Projeto em desenvolvimento para a disciplina de prática profissinal em análise e desenvolvimento de sistemas pelo grupo JEG. </p>

<h2> Objetivo do Projeto </h2>
<p> Desenvolver uma aplicação web com a finalidade de gerenciar campeonatos para a escola ChuteSal. </p>

<h2> Guia </h2>

<ol>
    <li> </li>
    <li> </li>
    <li> </li>
</ol>

<h2> Tecnologias Utilizadas </h2>

<ul>
    <li><strong>Java 11</strong></li>
    <li><strong>Maven</strong></li>
    <li><strong>Spring Web</strong></li>
    <li><strong>Spring Data JPA</strong></li>
    <li><strong>Spring Validation</strong></li>
    <li><strong>Spring DevTools</strong></li>
    <li><strong>Spring Security</strong></li>
    <li><strong>JWT</strong></li>
    <li><strong>Lombok</strong></li>
    <li><strong>MySQL</strong></li>
</ul>
